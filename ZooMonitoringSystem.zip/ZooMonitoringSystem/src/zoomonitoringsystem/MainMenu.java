/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoomonitoringsystem;

//imports

import java.util.Scanner;
import java.io.IOException;
import java.lang.*;
import java.io.FileInputStream;
import java.io.FileNotFoundException;


/**
 *
 * @author Kenny
 */
public class MainMenu {
    
    public static void mainMenu(String level) {
        
        //initializing classes
        Scanner scan = new Scanner(System.in);
        
        
        //initializing variables
        String selection = "Hi";
        
        //test output
        //System.out.println("Entered Main Menu");
        
        while(!selection.toLowerCase().equals("exit")){
            switch (level) {
                case "HR": 
                    System.out.println("Would you to view employee information or exit?");
                    selection = scan.nextLine();
                    
                    //Verification for selection
                    if(selection.toUpperCase().contains("EMPLOYEE") == false && selection.toUpperCase().contains("EXIT") == false ) {
                        while(selection.toUpperCase().contains("EMPLOYEE") == false && selection.toUpperCase().contains("EXIT") == false ){
                            System.out.println("Invalid choice\n");
                            System.out.println("Would you to view employee or exit?");
                            selection = scan.nextLine();
                        }
                    }
                    if(selection.toUpperCase().contains("EMPLOYEE")){
                        Employees.empHR();
                    }
                    
                    break;
                    
                case "ZK":
                    
                    System.out.println("Would you to view animal or habitat information or exit? \n" + "Please enter Animal, Habitat or Exit. \n");
                    selection = scan.nextLine();
                    
                    //Verification for selection
                    if(selection.toUpperCase().contains("ANIMAL") == false && selection.toUpperCase().contains("HABITAT") == false && selection.toUpperCase().contains("EXIT") == false ) {
                        while(selection.toUpperCase().contains("ANIMAL") == false && selection.toUpperCase().contains("HABITAT") == false && selection.toUpperCase().contains("EXIT") == false){
                            System.out.println("Invalid choice\n");
                            System.out.println("Would you an animal, a habitat, or exit?");
                            selection = scan.nextLine();
                        }
                    }
                    if(selection.toUpperCase().contains("ANIMAL")){
                        Animals.animalSearch();
                    }
                    
                    if(selection.toUpperCase().contains("HABITAT")){
                        Habitats.habitatSearch();
                    }
                    
                    break;
                    
                case "AD":
                    System.out.println("Would you to view employee, animal, or habitat information or exit? \n" + "Please enter Employee, Animal, Habitat or Exit. \n");
                    selection = scan.nextLine();
                    
                    //Verification for selection
                    if(selection.toUpperCase().contains("ANIMAL") == false && selection.toUpperCase().contains("HABITAT") == false && selection.toUpperCase().contains("EMPLOYEE") == false && selection.toUpperCase().contains("EXIT") == false ) {
                        while(selection.toUpperCase().contains("ANIMAL") == false && selection.toUpperCase().contains("HABITAT") == false && selection.toUpperCase().contains("EMPLOYEE") == false && selection.toUpperCase().contains("EXIT") == false ){
                            System.out.println("Invalid choice\n");
                            System.out.println("Would you to view employee, animal, habitat information, or exit?");
                            selection = scan.nextLine();
                        }
                    }
                    if(selection.toUpperCase().contains("ANIMAL")){
                        Animals.animalSearch();
                    }
                    
                    if(selection.toUpperCase().contains("HABITAT")){
                        Habitats.habitatSearch();
                    }
                    if(selection.toUpperCase().contains("EMPLOYEE")){
                        Employees.empHR();
                    }
                    
                    break;
                    
                    
            }
        }
        
}
    
}
