/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoomonitoringsystem;

//imports
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;


/**
 *
 * @author Kenny
 */
public class Login {
    public String publicLogin(String user, String pass){
        String userlevel;
       userlevel = loginCheck(user, pass);
       return userlevel;
    }
    
    private String loginCheck(String user, String pass) {
        //Initialization of method variables
        String access = null;
        String connectionUrl = "jdbc:sqlserver://localhost:56219;databaseName=ZooInformationSystem;user=ZooAppUser;password=123;";
        
        ResultSet rs;
        
        try (Connection connection = DriverManager.getConnection(connectionUrl);
                Statement statement = connection.createStatement();) {

            // Create and execute a SELECT SQL statement.
            //String selectSql = String.format(select, user, pass);
            String select = "SELECT userLevel From Users WHERE username = '%s' AND password = '%s' ";
            String stm = String.format(select, user, pass);
            
            rs = statement.executeQuery(stm);
            
            if(!rs.isBeforeFirst()) {
                access = "Invalid";
                return access;
            }
            rs.next();
            access = rs.getString(1);
            
            //access = "valid";
            
            //closing values for connections
            rs.close();
            connection.close();
            statement.close();
        }
        catch (SQLException e) {
            System.out.println("Error with SQL has occured. Please inform the developer.");
        }
       
        
        return access;
    }

}

