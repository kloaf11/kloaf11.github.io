/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoomonitoringsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Kenny
 */
public class Animals {
    
    public static void animalSearch(){
        
        //Class Initialization
        Scanner scan = new Scanner(System.in);
        
        //Initialization of method variables
        String connectionUrl = "jdbc:sqlserver://localhost:56219;databaseName=ZooInformationSystem;user=ZooAppUser;password=123;";
        String lookupChoice;
        String name;
        List<String> animalNames=new ArrayList<>();  
        List<String> animalTypes=new ArrayList<>();  
        List<Integer> animalIds=new ArrayList<>();  
        int id = 0;
        ResultSet rs;
        ResultSet rs2;
        boolean done = false;
        String select;
        int countId;
        
        
        // choice on what to search by
        System.out.println("Welcome to the animal record section. \n Would you look someone up by the animal ID, Type, or Name? Please Enter 'ID', 'Type', or 'Name' \n");
        lookupChoice = scan.nextLine();
        
        //Verification for selection
        if(lookupChoice.toUpperCase().contains("NAME") == false && lookupChoice.toUpperCase().contains("ID") == false && lookupChoice.toUpperCase().contains("TYPE") == false){
            while( lookupChoice.toUpperCase().contains("NAME") == false && lookupChoice.toUpperCase().contains("ID") && lookupChoice.toUpperCase().contains("TYPE") == false){
                System.out.println("Invalid choice\n");
                System.out.println("Invalid animal ID, Type, or Name? Please Enter 'ID', 'Type', or 'Name' \n");
                lookupChoice = scan.nextLine();
            }
        }
        
        
        
       
        
        try (Connection connection = DriverManager.getConnection(connectionUrl);
                Statement statement = connection.createStatement();) {
            
            
            //if searching by name
        if(lookupChoice.toUpperCase().contains("NAME")) {
            
            System.out.println("Please enter the name of the animal. \n");
            name = scan.nextLine();
            
            rs2 = statement.executeQuery("SELECT Name FROM Animals");
            
            while(rs2.next()){
                animalNames.add(rs2.getString(1));
            }
            
            //animal validation
            while(!done){
                
                for(String animal:animalNames) {
                    if(animal.toUpperCase().contains(name.toUpperCase())) {
                        done = true;
                        break;
                    }
                }
                if(!done) {
                   System.out.println("Please enter a valid name of an animal. \n");
                    name = scan.nextLine(); 
                }
                
            }
            
            select = nameSearch(name);
            
        }
        
        else if(lookupChoice.toUpperCase().contains("TYPE")) {
            
            System.out.println("Please enter the type of the animal. \n");
            name = scan.nextLine();
            
            rs2 = statement.executeQuery("SELECT DISTINCT AnimalType FROM Animals");
            
            while(rs2.next()){
                animalTypes.add(rs2.getString(1));
            }
            
            //animal type validation
            while(!done){
                
                for(String type:animalTypes) {
                    if(type.toUpperCase().contains(name.toUpperCase())) {
                        done = true;
                        break;
                    }
                }
                if(!done) {
                   System.out.println("Please enter a valid type of an animal. \n");
                    name = scan.nextLine(); 
                }
                
            }
            
            
            select = typeSearch(name);
        }
        
        //animal id search
        else{
            
            
            System.out.println("Please enter the ID of the Animal. \n");
            
            rs2 = statement.executeQuery("SELECT MAX(AnimalId) FROM Animals");
            
            rs2.next();
            
            countId = rs2.getInt(1);
            
            System.out.println("Max ID currently is " + countId + ". \n");
            
            while (id <= 0) {
                System.out.print("Enter an integer: ");
                try {
                    id = scan.nextInt();
                    if(id < 1 || id > countId){
                        System.out.println("Invalid ID number. Please enter a valid animal ID number between 1 and " + countId + ".\n");
                        id = scan.nextInt();
                    }
                }
                catch (InputMismatchException e) {
                    System.out.println("\tInvalid input must be a valid animal ID. \n Max ID currently is " + countId + ". \n");
                    scan.nextLine();  // Clear invalid input from scanner buffer.
                }
            }
            
            select = idSearch(id);
            
        }
        
            
            // Execute a SELECT SQL statement.
            
            rs = statement.executeQuery(select);
            
            if(!rs.isBeforeFirst()) {
                System.out.println("No Results Found");
            }
            
            while(rs.next()){
             
                System.out.println("\nID: " + rs.getInt(1) + " | Name: " + rs.getString(2).trim() + " | Age: " + rs.getString(3).trim() + " | Habitat ID: " + rs.getString(8).trim());
            
                if(rs.getInt(4) == 0) {
                    System.out.println("ALERT: Animal has not been fed today! Please locate zookeeper for habitat and have them feed the animal");
                }
                if(!rs.getString(7).toUpperCase().trim().contains("NONE")) {
                    System.out.println("WARNING: Health ALERT for animal: " + rs.getString(7).trim());
                }
            }
            System.out.println("\n");
            
            
            //closing values for connections
            rs.close();
            connection.close();
            statement.close();

            
        }
        catch (SQLException e) {
            System.out.println("Error with SQL has occured. Please inform the developer.");
        }
        
    }
    
    private static String nameSearch(String name) {
        String nameString;
        String fullString;
        
        nameString = "SELECT * From Animals WHERE Name = '%s'";
        fullString = String.format(nameString, name);
        
        return fullString;
    }
    
    private static String idSearch(int id){
        String idString;
        String sql;
        idString = "SELECT * From Animals WHERE Animalid = %d";
        sql = String.format(idString, id);
        return sql;
    }
    
    private static String typeSearch(String type) {
        String nameString;
        String fullString;
        
        nameString = "SELECT * From Animals WHERE AnimalType = '%s'";
        fullString = String.format(nameString, type);
        
        return fullString;
    }
    
}
