/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoomonitoringsystem;

//Imports
import java.util.Scanner;

/**
 *
 * @author Kenny
 */
public class ZooMonitoringSystem {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        //Class initialization
        Scanner scan = new Scanner(System.in);
        Login login = new Login();
        
        //Variable initilization
        String userSelection;
        String username;
        String password;
        String userRole = "Invalid";
        
        //Initializing SQL connection
        
        
        while(userRole.equals("Invalid")){
            System.out.println("Enter your Username: ");
            username = scan.nextLine();
            System.out.println("Enter your password: ");
            password = scan.nextLine();
            
            //calls the method to try and verify log in using the Users DB
            userRole = login.publicLogin(username, password);
            //validation for invalid and valid logins
            if(userRole.equals("Invalid")){
                System.out.println("Login was invalid.");
            }
            else {
                System.out.println("Login Successful\n\n");
            }
        
        }
        
        //fixing the whitespace given by the login()
        userRole = userRole.trim();
        
        //test outputs
        //System.out.println("Out of while loop");
        //System.out.println(userRole);
        
        // main menu program call
        MainMenu.mainMenu(userRole);
        
        
        
        //exiting main to terminate
        System.exit(0);
    }
    
}
