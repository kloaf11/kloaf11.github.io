/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoomonitoringsystem;

//imports
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.InputMismatchException;
import java.util.Scanner;


/**
 *
 * @author Kenny
 */
public class Employees {
    
    public static void empHR(){
        
        //Class Initialization
        Scanner scan = new Scanner(System.in);
        
        //Initialization of method variables
        String connectionUrl = "jdbc:sqlserver://localhost:56219;databaseName=ZooInformationSystem;user=ZooAppUser;password=123;";
        String lookupChoice;
        String lookup2;
        String first = " ";
        String last = " ";
        int id = 0;
        ResultSet rs;
        ResultSet rs2;
        boolean done = false;
        String select;
        int countId;
        
        
        // choice on what to search by
        System.out.println("Welcome to the employee record section. \n Would you look someone up by the employee ID or Name? Please Enter 'Name' or 'ID' \n");
        lookupChoice = scan.nextLine();
        
        //Verification for selection
        if(lookupChoice.toUpperCase().contains("NAME") == false && lookupChoice.toUpperCase().contains("ID") == false){
            while( lookupChoice.toUpperCase().contains("NAME") == false && lookupChoice.toUpperCase().contains("ID")){
                System.out.println("Invalid choice\n");
                System.out.println("Would you look someone up by the employee ID or Name? Please Enter 'Name' or 'ID'? \n");
                lookupChoice = scan.nextLine();
            }
        }
        
        
        
       
        
        try (Connection connection = DriverManager.getConnection(connectionUrl);
                Statement statement = connection.createStatement();) {
            
            
            //if searching by name
        if(lookupChoice.toUpperCase().contains("NAME")) {
            System.out.println("Would you look by First name, last name or both? Please enter 'First', 'Last', or 'Both' \n");
            lookup2 = scan.nextLine();
             //Verification for selection
            if(lookup2.toUpperCase().contains("FIRST") == false && lookup2.toUpperCase().contains("LAST") == false && lookup2.toUpperCase().contains("BOTH") == false ){
                while(lookup2.toUpperCase().contains("FIRST") == false && lookup2.toUpperCase().contains("LAST") == false && lookup2.toUpperCase().contains("BOTH") == false){
                    System.out.println("Invalid choice\n");
                    System.out.println("Would you look by First name, last name or both? Please enter 'First', 'Last', or 'Both' \n");
                    lookup2 = scan.nextLine();
                }
            }
            if(lookup2.toUpperCase().contains("FIRST")){
                System.out.println("Please enter the first name.");
                first = scan.nextLine();
                select = nameSearch(first, last);
            }
            else if(lookup2.toUpperCase().contains("LAST")){
                System.out.println("Please enter the last name.");
                last = scan.nextLine();
                select = nameSearch(first, last);
            }
            else{
                System.out.println("Please enter the first name.");
                first = scan.nextLine();
                System.out.println("Please enter the last name.");
                last = scan.nextLine();
                select = nameSearch(first, last);
            }
        }
        else{
            
            
            System.out.println("Please enter the ID of the employee. \n");
            
            rs2 = statement.executeQuery("SELECT MAX(id) FROM EMPLOYEES");
            
            rs2.next();
            
            countId = rs2.getInt(1);
            
            System.out.println("Max ID currently is " + countId + ". \n");
            
            while (id == 0) {
                System.out.print("Enter an integer: ");
                try {
                    id = scan.nextInt();
                    if(id < 1 || id > countId){
                        System.out.println("Invalid ID number. Please enter a valid employee ID number between 1 and " + countId + ".\n");
                        id = scan.nextInt();
                    }
                }
                catch (InputMismatchException e) {
                    System.out.println("\tInvalid input must be a valid Employee ID. \n Max ID currently is " + countId + ". \n");
                    scan.nextLine();  // Clear invalid input from scanner buffer.
                }
            }
            
            select = idSearch(id);
            
        }
        
            
            // Execute a SELECT SQL statement.
            
            rs = statement.executeQuery(select);
            
            if(!rs.isBeforeFirst()) {
                System.out.println("No Results Found");
            }
            
            while(rs.next()){
             System.out.println("\n\nID: " + rs.getInt(1) + " | First Name: " + rs.getString(2).trim() + " | Last Name: " + rs.getString(3).trim() + " | Position: " + rs.getString(4).trim() + " | Salary: "  + rs.getString(10).trim() + "\n\n");
                         
            }
            
            
            //closing values for connections
            rs.close();
            connection.close();
            statement.close();

            
        }
        catch (SQLException e) {
            System.out.println("Error with SQL has occured. Please inform the developer.");
        }
        
    }
    
    private static String nameSearch(String first, String last) {
        String nameString;
        String fullString;
        if(first.equals(" ")) {
            nameString = "SELECT * From Employees WHERE LastName = '%s'";
            fullString = String.format(nameString, last);
        }
        else if(last.equals(" ")) {
            nameString = "SELECT * From Employees WHERE FirstName = '%s'";
            fullString = String.format(nameString, first);
        }
        
        else {
            nameString = "SELECT * From Employees WHERE FirstName = '%s' AND lastName = '%s'";
            fullString = String.format(nameString, first, last);
        }
        
        return fullString;
    }
    
    private static String idSearch(int id){
        String idString;
        String fullString;
        idString = "SELECT * From Employees WHERE id = %d";
        fullString = String.format(idString, id);
        return fullString;
    }
    
}
