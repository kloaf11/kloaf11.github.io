/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package zoomonitoringsystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Kenny
 */
public class Habitats {
    
    
    public static void habitatSearch(){
        
        //Class Initialization
        Scanner scan = new Scanner(System.in);
        LocalDate date = LocalDate.now();
        
        //Initialization of method variables
        String connectionUrl = "jdbc:sqlserver://localhost:56219;databaseName=ZooInformationSystem;user=ZooAppUser;password=123;";
        String lookupChoice;
        String name;
        List<String> habitatNames=new ArrayList<>();  
        List<Integer> habitatIds=new ArrayList<>();  
        int id = 0;
        ResultSet rs;
        ResultSet rs2;
        boolean done = false;
        String select;
        int countId;
        
        
        // choice on what to search by
        System.out.println("Welcome to the habitat record section. \n Would you look someone up by the habitat ID or Name? Please Enter 'ID' or 'Name' \n");
        lookupChoice = scan.nextLine();
        
        //Verification for selection
        if(lookupChoice.toUpperCase().contains("NAME") == false && lookupChoice.toUpperCase().contains("ID") == false){
            while( lookupChoice.toUpperCase().contains("NAME") == false && lookupChoice.toUpperCase().contains("ID") == false){
                System.out.println("Invalid choice\n");
                System.out.println("Invalid habitat ID or Name? Please Enter 'ID' or 'Name' \n");
                lookupChoice = scan.nextLine();
            }
        }
        
        
        
       
        
        try (Connection connection = DriverManager.getConnection(connectionUrl);
                Statement statement = connection.createStatement();) {
            
            
            //if searching by name
        if(lookupChoice.toUpperCase().contains("NAME")) {
            
            System.out.println("Please enter the name of the habitat. \n");
            name = scan.nextLine();
            
            rs2 = statement.executeQuery("SELECT Name FROM habitats");
            
            while(rs2.next()){
                habitatNames.add(rs2.getString(1));
            }
            
            //habitat validation
            while(!done){
                
                for(String habitat:habitatNames) {
                    if(habitat.toUpperCase().contains(name.toUpperCase())) {
                        done = true;
                        break;
                    }
                }
                if(!done) {
                   System.out.println("Please enter a valid name of an animal. \n");
                    name = scan.nextLine(); 
                }
                
            }
            
            select = nameSearch(name);
            
        }
        
        //habitat id search
        else{
            
            
            System.out.println("Please enter the ID of the habitat. \n");
            
            rs2 = statement.executeQuery("SELECT Max(ID) FROM Habitats");
            
            rs2.next();
            
            countId = rs2.getInt(1);
            
            System.out.println("Max ID currently is " + countId + ". \n");
            
            while (id <= 0) {
                System.out.print("Enter an integer: ");
                try {
                    id = scan.nextInt();
                    if(id < 1 || id > countId){
                        System.out.println("Invalid ID number. Please enter a valid habitat ID number between 1 and " + countId + ".\n");
                        id = scan.nextInt();
                    }
                }
                catch (InputMismatchException e) {
                    System.out.println("\tInvalid input. Habitat ID is an integer. \n Max ID currently is " + countId + ". \n");
                    scan.nextLine();  // Clear invalid input from scanner buffer.
                }
            }
            
            select = idSearch(id);
            
        }
        
            
            // Execute a SELECT SQL statement.
            
            rs = statement.executeQuery(select);
            
            if(!rs.isBeforeFirst()) {
                System.out.println("No Results Found");
            }
            
            while(rs.next()){
             
                System.out.println("\nID: " + rs.getInt(1) + " | Name: " + rs.getString(2).trim() + " | Date Last Cleaned: " + rs.getString(3).trim() + " | Food Source " + rs.getString(4).trim() + " | Temperature: " + rs.getString(6).trim());
            }
            
            System.out.println("If any habitat last clean date is more than 4 days ago. Please contact proper ZooKeeper to clean the habitat\n \n");
            
            
            //closing values for connections
            rs.close();
            connection.close();
            statement.close();

            
        }
        catch (SQLException e) {
            System.out.println("Error with SQL has occured. Please inform the developer.");
        }
        
    }
    
    private static String nameSearch(String name) {
        String nameString;
        String fullString;
        
        nameString = "SELECT * From Habitats WHERE Name = '%s'";
        fullString = String.format(nameString, name);
        
        return fullString;
    }
    
    private static String idSearch(int id){
        String idString;
        String sql;
        idString = "SELECT * From Habitats WHERE id = %d";
        sql = String.format(idString, id);
        return sql;
    }
    
}
